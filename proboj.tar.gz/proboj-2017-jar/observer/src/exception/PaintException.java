package exception;

/**
 * Created by siegrift on 12/25/16.
 */
public class PaintException extends Exception {
    public PaintException(String s) {
        super(s);
    }
}
