package code;

/**
 * Created by siegrift on 12/26/16.
 */
public interface CanvasAnimation {
    void animate();
}
