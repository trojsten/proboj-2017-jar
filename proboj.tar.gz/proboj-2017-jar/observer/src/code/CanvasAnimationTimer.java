package code;

import javafx.animation.AnimationTimer;

/**
 * Created by siegrift on 12/27/16.
 */
public abstract class CanvasAnimationTimer extends AnimationTimer {
    CanvasAnimationTimer(int frame){
        super();
    }
}
