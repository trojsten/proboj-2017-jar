## Observer

Na rozbehanie observera treba pouzivat Oracle javu, mozno staci 
`sudo apt-get install oracle-java8-installer`
Tento link vsak aspon mne nefuguje.

Treba postupovat podla tohto linku

http://www.webupd8.org/2012/09/install-oracle-java-8-in-ubuntu-via-ppa.html

Ak toto nebude stacit treba skusit instrukcie z tohto linku.

'http://askubuntu.com/questions/430434/replace-openjdk-with-oracle-jdk-on-ubuntu'

### Pouzivanie observera

Observer sa standardne spusta v developer mode, //TODO dopisat